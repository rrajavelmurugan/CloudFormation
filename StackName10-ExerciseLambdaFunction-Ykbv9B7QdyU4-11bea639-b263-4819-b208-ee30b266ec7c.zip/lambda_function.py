import boto3
import os
import json
from botocore.exceptions import ClientError

ssm_client = boto3.client('ssm')
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    print(event)
    if event['RequestType'] == 'Delete':
        send_response(event, context, 'SUCCESS', {})
        return

    try:
        param = ssm_client.get_parameter(Name='UserName')
        param_value = param['Parameter']['Value']

        bucket_name = os.environ['S3_BUCKET']
        file_name = 'user_data.txt'
        file_content = f"UserName={param_value}"

        s3_client.put_object(Bucket=bucket_name, Key=file_name, Body=file_content)

        print(f"Successfully stored {param_value} in {bucket_name}/{file_name}")

        send_response(event, context, 'SUCCESS', {})
    except ClientError as e:
        print(f"Error: {e}")
        send_response(event, context, 'FAILED', {})

def send_response(event, context, response_status, response_data):
    response_url = event['ResponseURL']

    response_body = json.dumps({
        'Status': response_status,
        'Reason': 'See the details in CloudWatch Log Stream: ' + context.log_stream_name,
        'PhysicalResourceId': context.log_stream_name,
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': response_data
    })

    headers = {
        'Content-Type': '',
        'Content-Length': str(len(response_body))
    }

    try:
        response = requests.put(response_url, data=response_body, headers=headers)
        print('Status code:', response.reason)
    except Exception as e:
        print('send(..) failed executing requests.put(..):', str(e))